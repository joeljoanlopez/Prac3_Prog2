﻿using System;
using TCEngine;
using System.Xml.Linq;

namespace TCGame
{
    public class App
    {
        public static void Main()
        {
            TecnoCampusEngine.Get.Run(new Practica3());
        }
    }
}
